<?php

namespace WeDevs\Dokan\Abstracts;

use WeDevs\Dokan\REST\DokanBaseAdminController;

/**
* Admin Dashboard
*
* @since 2.8.0
* @deprecated 3.14.11 Use \WeDevs\Dokan\REST\DokanBaseAdminController instead.
*
* @package dokan
*/
abstract class DokanRESTAdminController extends DokanBaseAdminController {
}
