<?php

namespace WeDevs\Dokan\ThirdParty\Packages\Psr\Container;

/**
 * No entry was found in the container.
 */
interface NotFoundExceptionInterface extends ContainerExceptionInterface
{
}
