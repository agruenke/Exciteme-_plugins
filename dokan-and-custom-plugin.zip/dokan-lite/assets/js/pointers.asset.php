<?php return array('dependencies' => array(), 'version' => '11ee0d77168639385147');
