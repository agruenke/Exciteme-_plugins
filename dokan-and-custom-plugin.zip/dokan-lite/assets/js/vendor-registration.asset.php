<?php return array('dependencies' => array(), 'version' => '9d270537d144b5f93452');
