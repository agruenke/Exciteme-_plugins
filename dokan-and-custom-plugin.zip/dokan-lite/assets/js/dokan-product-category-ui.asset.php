<?php return array('dependencies' => array(), 'version' => 'b46deef63ccd59811fe9');
