<?php return array('dependencies' => array(), 'version' => '3d8f34cdd7947f2432ac');
