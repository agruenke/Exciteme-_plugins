<?php return array('dependencies' => array(), 'version' => 'af056d990c53511f5edd');
