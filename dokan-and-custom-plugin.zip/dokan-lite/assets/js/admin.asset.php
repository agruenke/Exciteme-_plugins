<?php return array('dependencies' => array(), 'version' => '19191391f7ba2dde7f39');
