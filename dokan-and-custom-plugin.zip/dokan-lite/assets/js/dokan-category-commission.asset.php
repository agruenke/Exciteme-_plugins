<?php return array('dependencies' => array(), 'version' => '4a136b17f01bebd2910b');
