<?php return array('dependencies' => array('dokan-stores-product-categories', 'dokan-stores-products', 'wp-api-fetch', 'wp-data', 'wp-element', 'wp-url'), 'version' => 'fb0b1e4aff9956c24870');
