<?php return array('dependencies' => array(), 'version' => 'a905a094cf0879493d52');
