<?php return array('dependencies' => array('jquery', 'moment', 'wp-i18n'), 'version' => 'd03fdc3e7fa01f69dd42');
