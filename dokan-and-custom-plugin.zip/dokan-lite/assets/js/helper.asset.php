<?php return array('dependencies' => array(), 'version' => 'fb5e74a426947d1949e3');
