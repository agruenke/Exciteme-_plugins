<?php return array('dependencies' => array('wc-date'), 'version' => '7766ab37959354c49c2b');
