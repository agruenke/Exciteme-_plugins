<?php return array('dependencies' => array('wp-api-fetch', 'wp-core-data', 'wp-data'), 'version' => '16d95b2a30911314f3eb');
