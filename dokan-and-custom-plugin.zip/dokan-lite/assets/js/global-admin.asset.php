<?php return array('dependencies' => array(), 'version' => '1b741ff325cb7a930f85');
