<?php return array('dependencies' => array(), 'version' => 'c3d05ab00faa8fd8b518');
