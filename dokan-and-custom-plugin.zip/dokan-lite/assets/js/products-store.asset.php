<?php return array('dependencies' => array('wp-api-fetch', 'wp-data', 'wp-url'), 'version' => '8128a35021086eb35efe');
