<?php return array('dependencies' => array('jquery', 'wp-i18n'), 'version' => '03b2799c55ef3dcc5d7d');
