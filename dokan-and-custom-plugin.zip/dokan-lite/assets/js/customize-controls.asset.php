<?php return array('dependencies' => array(), 'version' => '61e64c623da6a19ebce8');
