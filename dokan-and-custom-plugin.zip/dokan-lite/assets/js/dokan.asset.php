<?php return array('dependencies' => array(), 'version' => '381ccb34c9be951434b8');
