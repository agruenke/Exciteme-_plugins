<?php return array('dependencies' => array('jquery', 'moment'), 'version' => '4f04f2529b8f37296d7b');
