<?php return array('dependencies' => array(), 'version' => 'bf21e1b404b3814cc8f7');
