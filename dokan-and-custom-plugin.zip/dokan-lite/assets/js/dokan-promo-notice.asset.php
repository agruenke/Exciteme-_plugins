<?php return array('dependencies' => array('jquery'), 'version' => 'c11d54ced28784239031');
