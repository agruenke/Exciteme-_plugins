<?php return array('dependencies' => array(), 'version' => '51634b25b71af8a60401');
