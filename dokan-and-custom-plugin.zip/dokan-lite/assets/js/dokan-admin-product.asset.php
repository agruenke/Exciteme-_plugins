<?php return array('dependencies' => array(), 'version' => 'd9ce093b4e2c4a3aff0a');
