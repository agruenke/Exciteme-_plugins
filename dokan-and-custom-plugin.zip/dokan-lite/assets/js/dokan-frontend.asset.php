<?php return array('dependencies' => array(), 'version' => 'aa2a9aa0de9532f6c45d');
