<?php return array('dependencies' => array(), 'version' => 'a7e8f2bffe2daf21ce48');
