<?php return array('dependencies' => array(), 'version' => '8554610523227feea3ea');
