<?php return array('dependencies' => array(), 'version' => '6dfa430de189e0d8970e');
