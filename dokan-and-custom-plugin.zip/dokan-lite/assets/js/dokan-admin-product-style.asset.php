<?php return array('dependencies' => array(), 'version' => '247f3f4b1376f9849f1e');
